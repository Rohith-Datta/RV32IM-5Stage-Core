# Master specification review and delivery status

## Result and limits

The extracted top was `integration/modules/core/rv32imf_core.v`, containing `u_pipeline: pipeline_5stage`. There was no board top, UART, XDC, firmware startup/linker, or synthesizable unified program RAM in the ZIP. Those integration files are now present. This delivery is a tested integration candidate, not a claim of exact master-spec completion or production readiness.

## Original signal mapping and implemented connections

| Required observation | Actual source / implementation |
|---|---|
| IF PC | `rv32imf_core.pc_if`; internal `u_pipeline.if_pc` |
| WB PC/data/write | `pc_wb`, `wb_data`, `wb_reg_write` |
| WB destination | `wb_dest_reg`; widened to six bits for integer/FP banks |
| Retirement validity | internal `u_pipeline.wb_valid`; exported `retire_o` |
| Aggregate stall | `hazard_stall` |
| Load-use | original `u_pipeline.u_hazard_unit.load_use_hazard`; exported valid-qualified `load_use_o` |
| D-cache refill | `u_pipeline.u_dcache.state`, `refill_cnt`, `dcache_stall` |
| I-cache refill | `u_pipeline.u_icache.state`, `refill_cnt`, `icache_stall` |
| Branch resolution | `btb_mispredict`, `ex_redirect_pc` |
| FPU/divider | `fpu_busy`, `div_busy`; operation exception events added as `fp_flags_o` |
| Zbb | decoded EX activity exported as `zbb_active_o` |
| MMIO | new MEM-stage `mmio_*` interface; bypasses both caches and backing-RAM arbitration |

## Corrections made

- Original FP instructions read/wrote integer registers. Bank tags now travel through decode, pipeline registers, hazards and forwarding, including writable f0.
- Added the conversions, FP moves and sign-injection operations emitted by the demo compiler.
- Fixed loss of WB-forwarded operand values during prolonged EX stalls. A held ID/EX register now snoops retiring writes.
- Cache refill progress now honors bus grants and captures only valid read responses. Store requests wait for arbitration. D-cache bypass data now has one sequential writer, rather than multiple drivers.
- D-cache load refills now have ten stall cycles when arbitration does not add waiting. Original D-cache refill timing was shorter.
- Corrected subnormal significands, gradual underflow and RNE result packing for multiplication/division, plus subnormal addition packing. Added operation flags and read-only accrued flags.
- Remapped C03/C04/C05/C06 to D misses/I misses/stalls/mispredictions, as requested. C07 reports branches and C08 captures real WB data.
- Added a 64 KiB synchronous unified RAM, MMIO, UART mailbox/transmitter, 50 MHz clock generation, whole-core slow-clock gate, display and board constraints.
- Fixed the supplied LED counter array declaration, display counter slice and missing upper PC nibble slices.
- Removed invented firmware PCs, cycle numbers, stalls, cache misses and WB values. Integer divide-by-zero and overflow use inline ISA instructions rather than undefined C arithmetic. FP fault operations use explicit instructions rather than foldable expressions.
- Added startup, bounded stack, BSS initialization, linker script, ELF/binary/word-hex build and disassembly.
- Dashboard no longer claims every mismatch is a tolerance pass, returns diagnostic expected values independently of received results, validates packet order and exact shape, preserves partial serial lines, handles port selection/reconnect and labels synthetic input.

## Conflicts in the supplied specification

1. Its purported cycle logger prints hardcoded fictional traces; it cannot prove the processor's actual pipeline. Those records were removed, not presented as evidence.
2. Its CSV says nine fields but enumerates eleven numeric fields. The implementation uses the complete enumerated format.
3. Exact cache hit ratios and physical PC/LED state cannot be recovered from that CSV. Displaying fixed 98.8% or estimated PC values would be misleading.
4. A 50 MHz per-cycle ASCII trace cannot continuously fit through 115200-baud 8N1. At 100 bytes/record the capacity is about 115 records/s, not 50 million/s. FPGA capture plus replay, or a trace backpressure clock gate and UART packet arbitration, is required.
5. The supplied multiplication rounding vector is inexact but is not an exact halfway tie. Directed FADD halfway-even and halfway-odd cases were added.
6. Tiny exact subnormal outputs do not automatically require the IEEE underflow flag. The new tests distinguish exact subnormal generation from tiny inexact rounding.

## Requirements still incomplete or unverified

| Requirement | Status / remaining work |
|---|---|
| Every-cycle trace over the physical UART, SW12 | Not implemented. RTL observation logs are available; no fake UART trace is emitted. |
| Hybrid UART graph plus architectural trace | CSV works; physical trace capture/serialization and full disassembly formatting remain. |
| Complete RV32F and writable floating CSRs | Only demo-required operations and explicit RNE are implemented/tested. CSR read/write/clear semantics and remaining FP instructions need work. |
| All nine features and every corner case proven in one firmware pass | Coverage is distributed across directed benches, differential tests and separate mode runs. No single-run complete feature proof is claimed. |
| Bypassed stores each incur ten backing-memory cycles | Not implemented; original write-through/no-write-allocate stores remain grant-limited. Bypassed loads incur refill latency. |
| Full isolated latency profiler | Six instruction windows are measured; exact isolated EX/hit/miss latencies are not guaranteed by these CSR windows. |
| Guaranteed 95%+ cache hit rate / 0.95 IPC | Not guaranteed; counters are measured, not inflated. Cache counts require careful workload/acceptance definitions. |
| Live cache toggling during an active refill | Not verified; use stable switches and reset between runs. |
| Live PC/LED mirror and exact cache-hit gauges | Not in the fixed protocol; host marks missing information unavailable. |
| FPGA timing/resource fit and full UART board run | No Vivado/place-and-route/physical board execution. Board RTL elaboration and a serial-prefix simulation pass only. |
| UI visual inspection | Imports and headless parser tests passed; no interactive GUI window was visually inspected in this environment. |

## Verification evidence

- `baseline.log`: original unmodified RTL, original supplied bench — 19 checks pass. That bench used integer registers as FP storage, so it was not RV32F compliance evidence.
- `integration.log` / `tb_integrated_core.log`: corrected bank-aware integration program — 19 checks pass.
- `fpu_edges.log`: 12 directed arithmetic/result/flag checks pass, including real ties and exact/inexact subnormals.
- `fpu_vectors.log`: 2,784 deterministic differential RNE result vectors against NumPy binary32; zero mismatches. This is broad sampling, not exhaustive IEEE verification.
- `integer_edges.log`: 16 RV32M and Zbb boundary checks pass.
- `uart.log`, `display.log`: serial framing and eight-digit display checks pass.
- `board_smoke.log`: compiled firmware's first four output characters travel through MMIO, the mailbox and serial UART correctly. The UART divisor is accelerated in this test; the separate UART test uses the production divisor.
- `regression.log`: host parser tests and board-wrapper elaboration.
- `yosys_check.log`: Verilog lowering/hierarchy/connectivity check reports zero problems. Array-to-register warnings remain; this is not Xilinx synthesis or timing closure.
- `mode_results.log`: mode sweep, including an early cache-bypass test that hit its two-million-cycle testbench timeout after 91 matching packets. The limit was raised to three million for the final rerun; see `final_modes.log` for final results.

Pin assignments were taken from Digilent's official [Nexys A7-100T master XDC](https://github.com/Digilent/digilent-xdc/blob/master/Nexys-A7-100T-Master.xdc). SW8/SW9 retain the vendor's LVCMOS18 assignments; other selected ports retain their vendor standards. The original downloaded master is included alongside the selected project constraints.

## Final run summary

The final four-mode rerun completes all 100 packets for each mode, including cache bypass. All eleven diagnostic seed runs also complete. `transcript_verification.log` validates 1,500 received packets through the dashboard logic, including independent diagnostic expected values and division results, plus independently generated raw flight inputs. No transcript verification errors were found. This does not add coverage for missing physical UART trace, live cache switching, complete CSR semantics, or FPGA timing.
