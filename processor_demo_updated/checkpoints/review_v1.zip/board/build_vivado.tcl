# Run from the project root: vivado -mode batch -source board/build_vivado.tcl
create_project -force avionics build/vivado -part xc7a100tcsg324-1
set sources [glob integration/modules/*/*.v]
add_files $sources
add_files [glob board/*.v]
add_files avionics_demo.mem
set_property file_type {Memory Initialization Files} [get_files avionics_demo.mem]
set_property include_dirs [list [file normalize integration/modules/csr]] [current_fileset]
set_property verilog_define {SYNTHESIS} [current_fileset]
set_property top nexys_a7_top [current_fileset]
add_files -fileset constrs_1 board/nexys_a7.xdc
update_compile_order -fileset sources_1
launch_runs synth_1 -jobs 4
wait_on_run synth_1
if {[get_property PROGRESS [get_runs synth_1]] ne "100%"} {error "Synthesis failed"}
launch_runs impl_1 -to_step route_design -jobs 4
wait_on_run impl_1
open_run impl_1
report_timing_summary -file build/timing_summary.rpt
report_utilization -file build/utilization.rpt
report_drc -file build/drc.rpt
# Timing reports must be reviewed before generating/programming a bitstream.
