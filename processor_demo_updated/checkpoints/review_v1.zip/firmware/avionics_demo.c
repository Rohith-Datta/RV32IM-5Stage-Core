#include <stdint.h>

// =============================================================================
// 1. MEMORY-MAPPED I/O REGISTERS
// =============================================================================
#define MMIO_SWITCHES   (*((volatile uint32_t*)0x80000000))
#define MMIO_UART_TX    (*((volatile uint32_t*)0x80000004))
#define MMIO_SEG7_OVRD  (*((volatile uint32_t*)0x80000008))
#define MMIO_STATUS_LED (*((volatile uint32_t*)0x8000000C))

// =============================================================================
// 2. CSR & ZBB HARDWARE INSTRUCTION MACROS
// =============================================================================
#define READ_CSR(reg) ({ uint32_t __val; \
    __asm__ volatile ("csrr %0, " #reg : "=r"(__val)); __val; })

#define ZBB_REV8(rd, rs1) __asm__ volatile ("rev8 %0, %1" : "=r"(rd) : "r"(rs1))
#define ZBB_CPOP(rd, rs1) __asm__ volatile ("cpop %0, %1" : "=r"(rd) : "r"(rs1))
#define ZBB_CLZ(rd, rs1)  __asm__ volatile ("clz  %0, %1" : "=r"(rd) : "r"(rs1))
#define ZBB_CTZ(rd, rs1)  __asm__ volatile ("ctz  %0, %1" : "=r"(rd) : "r"(rs1))
#define ZBB_MAX(rd, rs1, rs2)  __asm__ volatile ("max  %0, %1, %2" : "=r"(rd) : "r"(rs1), "r"(rs2))
#define ZBB_MAXU(rd, rs1, rs2) __asm__ volatile ("maxu %0, %1, %2" : "=r"(rd) : "r"(rs1), "r"(rs2))

typedef union {
    float    f;
    uint32_t i;
} FloatHex;

// =============================================================================
// 3. LIGHTWEIGHT BARE-METAL UART DRIVER (NO PRINTF BLOAT)
// =============================================================================
static void uart_putc(char c) {
    while (MMIO_UART_TX & 0x80000000u); // Wait while UART TX is busy
    MMIO_UART_TX = (uint32_t)(uint8_t)c;
}

static void uart_puts(const char* s) {
    while (*s) {
        uart_putc(*s++);
    }
}

static void uart_put_hex32(uint32_t val) {
    const char hex_lut[16] = "0123456789ABCDEF";
    for (int nib = 7; nib >= 0; nib--) {
        uart_putc(hex_lut[(val >> (nib * 4)) & 0xFu]);
    }
}

static void uart_put_dec4(uint32_t val) {
    char buf[4];
    buf[3] = '0' + (val % 10u); val /= 10u;
    buf[2] = (val > 0) ? ('0' + (val % 10u)) : ' '; val /= 10u;
    buf[1] = (val > 0) ? ('0' + (val % 10u)) : ' '; val /= 10u;
    buf[0] = (val > 0) ? ('0' + (val % 10u)) : ' ';
    for (int i = 0; i < 4; i++) uart_putc(buf[i]);
}

// =============================================================================
// 5. MAIN AVIONICS TELEMETRY & VERIFICATION LOOP
// =============================================================================
static uint32_t hw_divu(uint32_t a, uint32_t b) { uint32_t r; __asm__ volatile("divu %0,%1,%2":"=r"(r):"r"(a),"r"(b)); return r; }
static uint32_t hw_div(int32_t a, int32_t b) { uint32_t r; __asm__ volatile("div %0,%1,%2":"=r"(r):"r"(a),"r"(b)); return r; }
static float fp_add(float a,float b){float r;__asm__ volatile("fadd.s %0,%1,%2,rne":"=f"(r):"f"(a),"f"(b));return r;}
static float fp_sub(float a,float b){float r;__asm__ volatile("fsub.s %0,%1,%2,rne":"=f"(r):"f"(a),"f"(b));return r;}
static float fp_mul(float a,float b){float r;__asm__ volatile("fmul.s %0,%1,%2,rne":"=f"(r):"f"(a),"f"(b));return r;}
static float fp_div(float a,float b){float r;__asm__ volatile("fdiv.s %0,%1,%2,rne":"=f"(r):"f"(a),"f"(b));return r;}
int main(void) {
    MMIO_STATUS_LED = 0x0u; // Clear DEMO_COMPLETE LED

    // Big-Endian Network Order IMU Telemetry Stream (100 Packets)
    // Includes normal flight curve, vibration spikes, and negative glitch packets
    volatile uint32_t telemetry_network_buffer[100];
    for (uint32_t k = 0; k < 100; k++) {
        // Generate Big-Endian IEEE-754 float values around 1.0f..8.0f
        // 0x0000803F rev8 -> 0x3F800000 (1.0f)
        // 0x00000040 rev8 -> 0x40000000 (2.0f)
        // 0x00004040 rev8 -> 0x40400000 (3.0f)
        // 0x00008040 rev8 -> 0x40800000 (4.0f)
        uint32_t base_le = 0x3F800000u + ((k % 16u) * 0x00100000u);
        if (k % 7u == 0u) base_le += 0x00600000u; // High-frequency vibration noise spike
        uint32_t be_packet;
        ZBB_REV8(be_packet, base_le);
        telemetry_network_buffer[k] = be_packet;
    }

    uint32_t sw_initial   = MMIO_SWITCHES & 0xFFFFu;
    uint32_t mode         = (sw_initial >> 14) & 0x3u;
    uint32_t cache_en     = (sw_initial >> 13) & 0x1u;
    uint32_t verbose_mode = (sw_initial >> 12) & 0x1u;
    uint32_t slow_mode    = (sw_initial >> 11) & 0x1u;
    uint32_t input_seed   = (sw_initial & 0xFFu);

    FloatHex ema_filtered;
    ema_filtered.f = 0.0f;

    

    // Measure baseline CSR read overhead for Cycle Latency Profiler
    uint32_t t_base0 = READ_CSR(cycle);
    uint32_t t_base1 = READ_CSR(cycle);
    uint32_t csr_overhead = t_base1 - t_base0;

    for (uint32_t iter = 0; iter < 100; iter++) {
        // Poll switches live on every packet so user can flip switches mid-run
        uint32_t sw_live = MMIO_SWITCHES & 0xFFFFu;
        mode         = (sw_live >> 14) & 0x3u;
        cache_en     = (sw_live >> 13) & 0x1u;
        verbose_mode = (sw_live >> 12) & 0x1u;
        slow_mode    = (sw_live >> 11) & 0x1u;
        input_seed   = (sw_live & 0xFFu);

        FloatHex alpha, one_minus_alpha, input_val;
        alpha.f           = (float)input_seed / 255.0f;
        one_minus_alpha.f = 1.0f - alpha.f;

        uint32_t zbb_out     = 0;
        uint32_t int_div_out = 0;
        uint32_t wb_commit   = 0;

        if (mode == 0x3u) {
            // =================================================================
            // MODE 3: DIAGNOSTIC FAULT INJECTION & CORNER CASE VERIFICATION
            // =================================================================
            volatile uint32_t zero_int = 0u;
            volatile int32_t  min_int  = (int32_t)0x80000000;
            volatile int32_t  neg_one  = -1;
            FloatHex f_zero, f_pos_one, f_neg_one, f_inf;
            f_zero.i    = 0x00000000u;
            f_pos_one.f = 1.0f;
            f_neg_one.f = -1.0f;

            if (input_seed == 0x01u) {
                // Edge Case: +Infinity via +1.0f / 0.0f
                input_val.f = fp_div(f_pos_one.f,f_zero.f);
                int_div_out = hw_divu(0x12345678u,zero_int); // Also test RV32M Div/0 -> 0xFFFFFFFF
            } else if (input_seed == 0x02u) {
                // Edge Case: -Infinity via -1.0f / 0.0f
                input_val.f = fp_div(f_neg_one.f,f_zero.f);
                int_div_out = hw_divu(0x12345678u,zero_int);
            } else if (input_seed == 0x03u) {
                // Edge Case: Quiet NaN (0x7FC00000) via 0.0f / 0.0f
                input_val.f = fp_div(f_zero.f,f_zero.f);
                int_div_out = hw_divu(0xFFFFFFFFu,zero_int);
            } else if (input_seed == 0x04u) {
                // Edge Case: Quiet NaN (0x7FC00000) via Inf - Inf
                f_inf.f     = fp_div(f_pos_one.f,f_zero.f);
                input_val.f = fp_sub(f_inf.f,f_inf.f);
                int_div_out = hw_div(min_int,neg_one); // Signed overflow -> 0x80000000
            } else if (input_seed == 0x05u) {
                // Edge Case: Quiet NaN (0x7FC00000) via 0.0f * Inf
                f_inf.f     = fp_div(f_pos_one.f,f_zero.f);
                input_val.f = fp_mul(f_zero.f,f_inf.f);
                int_div_out = hw_divu(0xABCD0000u,zero_int);
            } else if (input_seed == 0x06u) {
                // Edge Case: Signed Negative Zero (-0.0f)
                FloatHex neg_z; neg_z.i = 0x80000000u;
                input_val.f = fp_add(neg_z.f,neg_z.f);
                int_div_out = 0u;
            } else if (input_seed == 0x07u) {
                // Edge Case: RNE Guard/Round/Sticky Tie-to-Even
                FloatHex a, b;
                a.i = 0x3F800001u; b.i = 0x3F000001u;
                input_val.f = fp_mul(a.f,b.f);
                int_div_out = 1u;
            } else if (input_seed == 0x08u) {
                // Edge Case: Explicit Integer Divide-by-Zero
                int_div_out = hw_divu(0xCAFEBABEu,zero_int); // Must be 0xFFFFFFFF
                input_val.i = int_div_out;
            } else if (input_seed == 0x09u) {
                // Edge Case: Explicit Integer Signed Overflow (INT_MIN / -1)
                int_div_out = hw_div(min_int,neg_one); // Must be 0x80000000
                input_val.i = int_div_out;
            } else if (input_seed == 0x0Au) {
                // Edge Case: Zbb Signed MAX vs Unsigned MAXU
                uint32_t s_max, u_max;
                ZBB_MAX(s_max, 0xFFFFFFFFu, 5u);  // Returns 5
                ZBB_MAXU(u_max, 0xFFFFFFFFu, 5u); // Returns 0xFFFFFFFF
                input_val.i = s_max;
                int_div_out = u_max;
            } else if (input_seed == 0x0Bu) {
                // Edge Case: Zbb CLZ(0) = 32, CTZ(0) = 32, CPOP(0xFFFFFFFF) = 32
                uint32_t clz_v, ctz_v;
                ZBB_CLZ(clz_v, 0x00000000u);
                ZBB_CTZ(ctz_v, 0x00000000u);
                input_val.i = (clz_v << 16) | ctz_v;
                ZBB_CPOP(int_div_out, 0xFFFFFFFFu);
            } else {
                // Raw switch seed injection
                input_val.i = sw_live;
                int_div_out = hw_divu((uint32_t)sw_live,zero_int);
            }

            // Always run Zbb CPOP on the resulting bit pattern
            ZBB_CPOP(zbb_out, input_val.i);
            ema_filtered.i = input_val.i; // Pass fault directly to output for bit-exact verification
            wb_commit      = ema_filtered.i;

        } else {
            // =================================================================
            // MODE 0 / 1 / 2: NORMAL AVIONICS FLIGHT TELEMETRY FILTER
            // =================================================================
            uint32_t raw_net_pkt = telemetry_network_buffer[iter];

            // Feature 9 (Zbb): 1-Cycle Endian Swap (Big-Endian -> Little-Endian)
            uint32_t swapped_pkt;
            uint32_t t0 = READ_CSR(cycle);
            ZBB_REV8(swapped_pkt, raw_net_pkt);
            uint32_t t1 = READ_CSR(cycle);
            uint32_t zbb_cycles = (t1 - t0 > csr_overhead) ? (t1 - t0 - csr_overhead) : 1u;

            // Feature 9 (Zbb): 1-Cycle Signed Safety Clamp (Hard-Deck >= 0)
            ZBB_MAX(input_val.i, swapped_pkt, 0x00000000u);

            // Feature 9 (Zbb): 1-Cycle Parity Bit Population Count
            ZBB_CPOP(zbb_out, input_val.i);

            // Feature 4 (IEEE-754 FPU): Exponential Moving Average Filter
            if (iter == 0u) {
                ema_filtered.f = input_val.f;
            } else {
                ema_filtered.f = fp_add(fp_mul(alpha.f,input_val.f),fp_mul(one_minus_alpha.f,ema_filtered.f));
            }

            int_div_out = hw_divu(iter + 100u, 7u); // Report isolated Zbb cycle latency (1 cycle)
            wb_commit   = ema_filtered.i;
        }

        if (mode == 2u) {
            static volatile uint32_t thrash[1024] __attribute__((aligned(2048)));
            for(uint32_t j=0;j<16;j++) { uint32_t index=(j&1u)*512u; thrash[index]=iter+j; int_div_out ^= thrash[index]; }
        }
        if (mode == 1u && iter == 0) {
            static volatile uint32_t profile_memory[1024] __attribute__((aligned(2048)));
            uint32_t begin,end,result;
            float fp_result;
            profile_memory[0]=0x3f800000;
            profile_memory[512]=0x40000000;
            result=profile_memory[512];
#define PROFILE_PRINT(label) do { uart_puts("PROFILE," label ","); uart_put_hex32(end-begin-csr_overhead); uart_putc('\n'); } while(0)
            __asm__ volatile("csrr %0,cycle\nrev8 %2,%3\ncsrr %1,cycle" : "=&r"(begin),"=&r"(end),"=&r"(result):"r"(input_val.i):"memory");
            PROFILE_PRINT("REV8_WINDOW");
            __asm__ volatile("csrr %0,cycle\nlw %2,0(%3)\nadd %2,%2,zero\ncsrr %1,cycle" : "=&r"(begin),"=&r"(end),"=&r"(result):"r"(&profile_memory[0]):"memory");
            PROFILE_PRINT("DCACHE_CONFLICT_LOAD_WINDOW");
            __asm__ volatile("csrr %0,cycle\nlw %2,0(%3)\nadd %2,%2,zero\ncsrr %1,cycle" : "=&r"(begin),"=&r"(end),"=&r"(result):"r"(&profile_memory[0]):"memory");
            PROFILE_PRINT("DCACHE_HIT_LOAD_WINDOW");
            __asm__ volatile("csrr %0,cycle\nfmul.s %2,%3,%4,rne\ncsrr %1,cycle" : "=&r"(begin),"=&r"(end),"=&f"(fp_result):"f"(input_val.f),"f"(alpha.f):"memory");
            PROFILE_PRINT("FMUL_WINDOW");
            __asm__ volatile("csrr %0,cycle\nfdiv.s %2,%3,%4,rne\ncsrr %1,cycle" : "=&r"(begin),"=&r"(end),"=&f"(fp_result):"f"(input_val.f),"f"(alpha.f):"memory");
            PROFILE_PRINT("FDIV_WINDOW");
            __asm__ volatile("csrr %0,cycle\ndiv %2,%3,%4\ncsrr %1,cycle" : "=&r"(begin),"=&r"(end),"=&r"(result):"r"(12345678),"r"(13):"memory");
            PROFILE_PRINT("DIV_WINDOW");
#undef PROFILE_PRINT
        }
        // Write latest WB result to MMIO override register in case SW[10] is flipped
        MMIO_SEG7_OVRD = wb_commit;

        // Read Hardware Performance CSRs
        uint32_t csr_cycles  = READ_CSR(cycle);
        uint32_t csr_instret = READ_CSR(instret);
        uint32_t csr_dmiss   = READ_CSR(0xC03);
        uint32_t csr_stalls  = READ_CSR(0xC05);

        uint32_t csr_last_wb = READ_CSR(0xC08);
        // Transmit Real-Time Telemetry CSV Line
        uart_puts("CSV,");
        uart_put_hex32(iter);           uart_putc(',');
        uart_put_hex32(sw_live);        uart_putc(',');
        uart_put_hex32(input_val.i);    uart_putc(',');
        uart_put_hex32(ema_filtered.i); uart_putc(',');
        uart_put_hex32(zbb_out);        uart_putc(',');
        uart_put_hex32(int_div_out);    uart_putc(',');
        uart_put_hex32(csr_cycles);     uart_putc(',');
        uart_put_hex32(csr_instret);    uart_putc(',');
        uart_put_hex32(csr_dmiss);      uart_putc(',');
        uart_put_hex32(csr_stalls);     uart_putc(',');
        uart_put_hex32(csr_last_wb);    uart_putc('\n');

        // Pacing delay (longer if SW[11] Slow Mode is active so 7-seg PC is visible)
        uint32_t delay_loops = 0; // UART provides pacing; slow clock is controlled in hardware.
        for (volatile uint32_t d = 0; d < delay_loops; d++);
    }

    // Assert DEMO_COMPLETE LED[0] and transmit completion sentinel
    uart_puts("DEMO_COMPLETE\n");
    while (MMIO_UART_TX & 0x80000000u) {}
    MMIO_STATUS_LED = 0x1u;

    // Safe Bare-Metal Halt
    while (1) {
        __asm__ volatile ("nop");
    }
    return 0;
}
