import re
import sys
import time
import math
import queue
import struct
import threading
import tkinter as tk
import customtkinter as ctk
import serial
import serial.tools.list_ports
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# =============================================================================
# GLOBAL CONFIGURATION
# =============================================================================
DEFAULT_PORT = "COM3"
BAUD_RATE    = 115200
MAX_LOG_LINES = 10000

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("dark-blue")


# =============================================================================
# HOST GOLDEN REFERENCE MATHEMATICAL MODEL (IEEE-754 + RV32M + ZBB)
# =============================================================================
class HostGoldenModel:
    def __init__(self):
        self.ema_state = 0.0

    def reset(self):
        self.ema_state = 0.0

    @staticmethod
    def f32(val: float) -> float:
        """Force Python 64-bit float to exact 32-bit IEEE-754 single precision."""
        return struct.unpack("!f", struct.pack("!f", float(val)))[0]

    @staticmethod
    def float_to_hex(val: float) -> str:
        if math.isnan(val):
            return "7FC00000"
        return f"{struct.unpack('!I', struct.pack('!f', val))[0]:08X}"

    @staticmethod
    def hex_to_float(hex_str: str) -> float:
        raw = int(hex_str, 16) & 0xFFFFFFFF
        return struct.unpack("!f", struct.pack("!I", raw))[0]

    @staticmethod
    def zbb_cpop(val: int) -> int:
        return bin(val & 0xFFFFFFFF).count("1")

    def step(self, iter_idx: int, sw_val: int, raw_hex: str) -> tuple[str, int, str]:
        """Returns (expected_fpu_hex, expected_cpop, fault_description)"""
        mode       = (sw_val >> 14) & 0x3
        input_seed = sw_val & 0xFF
        raw_int    = int(raw_hex, 16) & 0xFFFFFFFF
        expected_cpop = self.zbb_cpop(raw_int)

        if mode == 0x3:
            # Diagnostic Fault Injection Mode
            desc_map = {
                0x01: "+Infinity (1.0f / 0.0f) [DZ=1]",
                0x02: "-Infinity (-1.0f / 0.0f) [DZ=1]",
                0x03: "Quiet NaN (0.0f / 0.0f) [NV=1]",
                0x04: "Quiet NaN (Inf - Inf) [NV=1]",
                0x05: "Quiet NaN (0.0f * Inf) [NV=1]",
                0x06: "Signed Negative Zero (-0.0f)",
                0x07: "IEEE-754 RNE Tie-to-Even (GRS)",
                0x08: "RV32M Int Div/0 -> 0xFFFFFFFF (-1)",
                0x09: "RV32M Signed Overflow (INT_MIN/-1)",
                0x0A: "Zbb Signed MAX vs Unsigned MAXU",
                0x0B: "Zbb Boundary CLZ(0)=32, CTZ(0)=32",
            }
            desc = desc_map.get(input_seed, f"Raw Seed Fault (0x{input_seed:02X})")
            expected = {1:0x7F800000,2:0xFF800000,3:0x7FC00000,4:0x7FC00000,5:0x7FC00000,
                        6:0x80000000,7:0x3F000002,8:0xFFFFFFFF,9:0x80000000,10:5,11:0x00200020}.get(input_seed,sw_val)
            return f"{expected:08X}", self.zbb_cpop(expected), desc

        # Normal Flight Mode EMA Filter
        alpha = self.f32(float(input_seed) / 255.0)
        one_minus_alpha = self.f32(1.0 - alpha)
        x_val = self.hex_to_float(raw_hex)

        if iter_idx == 0:
            self.ema_state = x_val
        else:
            term1 = self.f32(alpha * x_val)
            term2 = self.f32(one_minus_alpha * self.ema_state)
            self.ema_state = self.f32(term1 + term2)

        exp_hex = self.float_to_hex(self.ema_state)
        return exp_hex, expected_cpop, f"Flight EMA (alpha={alpha:.3f})"


# =============================================================================
# CUSTOM CIRCULAR ARC GAUGE WIDGET
# =============================================================================
class CircularGauge(tk.Canvas):
    def __init__(self, parent, title: str, max_val: float, unit: str, color: str):
        super().__init__(parent, width=175, height=155, bg="#252526", highlightthickness=0)
        self.title   = title
        self.max_val = max_val
        self.unit    = unit
        self.color   = color

        # Background Arc
        self.create_arc(20, 15, 155, 150, start=210, extent=-240,
                        style=tk.ARC, outline="#3A3D41", width=12)
        # Foreground Value Arc
        self.fg_arc = self.create_arc(20, 15, 155, 150, start=210, extent=0,
                                      style=tk.ARC, outline=self.color, width=12)
        # Numeric Readout
        self.val_text = self.create_text(87, 80, text=f"0{self.unit}",
                                         fill="#FFFFFF", font=("Consolas", 16, "bold"))
        # Title Label
        self.create_text(87, 135, text=self.title,
                         fill="#CCCCCC", font=("Consolas", 10, "bold"))

    def set_value(self, val: float):
        if val is None:
            self.itemconfig(self.fg_arc,extent=0)
            self.itemconfig(self.val_text,text="N/A")
            return
        clamped = max(0.0, min(val, self.max_val))
        ratio   = clamped / self.max_val if self.max_val > 0 else 0.0
        extent  = -240.0 * ratio
        self.itemconfig(self.fg_arc, extent=extent)
        if self.unit == "%":
            self.itemconfig(self.val_text, text=f"{val:.1f}%")
        elif self.max_val <= 2.0:
            self.itemconfig(self.val_text, text=f"{val:.2f}")
        else:
            self.itemconfig(self.val_text, text=f"{int(val)}")


# =============================================================================
# MAIN HYBRID VERIFICATION DASHBOARD
# =============================================================================
class RISCVTelemetryDashboard(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("RV32IMF+Zbb Avionics Telemetry & Micro-Architectural Verification Dashboard")
        self.geometry("1680x960")
        self.configure(fg_color="#1E1E1E")

        self.data_queue      = queue.Queue(maxsize=20000)
        self.golden_model    = HostGoldenModel()
        self.pause_autoscroll = False
        self.log_line_count  = 0
        self.serial_conn     = None
        self.running         = True
        self.sim_running     = False

        # Telemetry History Arrays
        self.x_iters  = []
        self.y_raw    = []
        self.y_filt   = []

        self.prev_cycles  = 0
        self.prev_instret = 0
        self.prev_dmiss   = 0

        self.port_name = DEFAULT_PORT
        self.source = "LIVE"
        self.received = set()
        self.failures = 0
        self.last_iter = -1
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW",self._close)
        self._start_serial_thread()
        self.after(30, self._process_queue)

    # -------------------------------------------------------------------------
    # UI CONSTRUCTION
    # -------------------------------------------------------------------------
    def _build_ui(self):
        self.grid_columnconfigure(0, weight=5)
        self.grid_columnconfigure(1, weight=5)
        self.grid_rowconfigure(0, weight=5) # Top Visualizations
        self.grid_rowconfigure(1, weight=0) # Control & Verification Ribbon
        self.grid_rowconfigure(2, weight=5) # Cycle-by-Cycle Trace Terminal

        # 1. TOP-LEFT PANEL: FPU TELEMETRY GRAPH
        self.graph_frame = ctk.CTkFrame(self, fg_color="#252526", corner_radius=8)
        self.graph_frame.grid(row=0, column=0, padx=(10, 5), pady=(10, 5), sticky="nsew")
        self.graph_frame.grid_rowconfigure(0, weight=1)
        self.graph_frame.grid_columnconfigure(0, weight=1)

        self.fig = Figure(figsize=(7, 3.8), dpi=100, facecolor="#252526")
        self.ax  = self.fig.add_subplot(111, facecolor="#1E1E1E")
        self.ax.set_title("Avionics IMU Telemetry: IEEE-754 FPU EMA Low-Pass Filter",
                          color="#39FF14", fontname="Consolas", fontsize=11, fontweight="bold")
        self.ax.set_xlabel("Packet Iteration (0 - 99)", color="#CCCCCC", fontname="Consolas", fontsize=9)
        self.ax.set_ylabel("Sensor Amplitude", color="#CCCCCC", fontname="Consolas", fontsize=9)
        self.ax.tick_params(colors="#CCCCCC", labelsize=8)
        self.ax.grid(True, color="#333333", linestyle="--", linewidth=0.6)

        self.line_raw,  = self.ax.plot([], [], "--", color="#00FFFF", linewidth=1.3, label="Raw IMU Packet (Zbb rev8)")
        self.line_filt, = self.ax.plot([], [], "-",  color="#39FF14", linewidth=2.4, label="FPGA FPU EMA Filtered")
        self.ax.legend(loc="upper right", facecolor="#252526", edgecolor="#39FF14", labelcolor="#FFFFFF", fontsize=8)

        self.canvas = FigureCanvasTkAgg(self.fig, master=self.graph_frame)
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew", padx=6, pady=6)

        # 2. TOP-RIGHT PANEL: CSR GAUGES + HOST VS FPGA PROOF CARD
        self.right_frame = ctk.CTkFrame(self, fg_color="#252526", corner_radius=8)
        self.right_frame.grid(row=0, column=1, padx=(5, 10), pady=(10, 5), sticky="nsew")
        self.right_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        self.gauge_ipc    = CircularGauge(self.right_frame, "LIVE IPC", 1.2, "", "#39FF14")
        self.gauge_dcache = CircularGauge(self.right_frame, "D-CACHE HIT", 100.0, "%", "#00FFFF")
        self.gauge_icache = CircularGauge(self.right_frame, "I-CACHE HIT", 100.0, "%", "#00FFFF")
        self.gauge_stalls = CircularGauge(self.right_frame, "PIPELINE STALLS", 5000.0, "", "#FF5555")

        self.gauge_ipc.grid(row=0, column=0, padx=4, pady=6)
        self.gauge_dcache.grid(row=0, column=1, padx=4, pady=6)
        self.gauge_icache.grid(row=0, column=2, padx=4, pady=6)
        self.gauge_stalls.grid(row=0, column=3, padx=4, pady=6)

        # Mathematical Proof & Edge-Case Verification Card
        self.proof_card = ctk.CTkFrame(self.right_frame, fg_color="#141414", corner_radius=6, border_width=1, border_color="#39FF14")
        self.proof_card.grid(row=1, column=0, columnspan=4, padx=10, pady=(4, 8), sticky="nsew")
        self.proof_card.grid_columnconfigure(0, weight=1)

        self.lbl_mode = ctk.CTkLabel(self.proof_card, text="MODE: FLIGHT TELEMETRY (00) | SW[15:0]: 0x2032 | 7-SEG PC: 0x00000000",
                                     font=("Consolas", 12, "bold"), text_color="#00FFFF", anchor="w")
        self.lbl_mode.grid(row=0, column=0, padx=10, pady=(6, 2), sticky="ew")

        self.lbl_fpga_vs_host = ctk.CTkLabel(
            self.proof_card,
            text="FPGA Computed : 0x00000000 (0.000000)  |  Host Expected : 0x00000000 (0.000000)\n"
                 "Zbb CPOP Bits : 0                      |  RV32M Div Out : 0x00000001\n"
                 "Latest WB Reg : 0x00000000             |  VERIFICATION  : WAITING FOR STREAM...",
            font=("Consolas", 12), text_color="#FFFFFF", justify="left", anchor="w"
        )
        self.lbl_fpga_vs_host.grid(row=1, column=0, padx=10, pady=(2, 8), sticky="ew")

        # 3. MIDDLE RIBBON: CONTROLS & STATUS
        self.ctrl_frame = ctk.CTkFrame(self, fg_color="#252526", corner_radius=8)
        self.ctrl_frame.grid(row=1, column=0, columnspan=2, padx=10, pady=4, sticky="ew")

        self.lbl_status = ctk.CTkLabel(self.ctrl_frame, text=" STATUS: LISTENING ON UART ",
                                       fg_color="#333333", text_color="#00FFFF",
                                       corner_radius=4, font=("Consolas", 12, "bold"))
        self.lbl_status.pack(side="left", padx=10, pady=6)

        self.port_menu = ctk.CTkComboBox(self.ctrl_frame, width=110,
            values=[p.device for p in serial.tools.list_ports.comports()] or [DEFAULT_PORT], command=self._select_port)
        self.port_menu.set(DEFAULT_PORT)
        self.port_menu.pack(side="left",padx=4)
        self.btn_pause = ctk.CTkButton(self.ctrl_frame, text="Pause Auto-Scroll: OFF",
                                       fg_color="#005577", hover_color="#0077AA",
                                       font=("Consolas", 12, "bold"), command=self._toggle_autoscroll)
        self.btn_pause.pack(side="left", padx=8, pady=6)

        self.btn_clear = ctk.CTkButton(self.ctrl_frame, text="Reset / Clear Run",
                                       fg_color="#444444", hover_color="#666666",
                                       font=("Consolas", 12), command=self._clear_dashboard)
        self.btn_clear.pack(side="left", padx=8, pady=6)

        # Demo Replay / Simulation Trigger (For testing or backup without board)
        self.btn_sim_flight = ctk.CTkButton(self.ctrl_frame, text="Synthetic flight",
                                            fg_color="#1F6F3E", hover_color="#288E4F",
                                            font=("Consolas", 12, "bold"),
                                            command=lambda: self._start_demo_sim(mode=0, cache_en=1, seed=0x32))
        self.btn_sim_flight.pack(side="right", padx=8, pady=6)

        self.btn_sim_fault = ctk.CTkButton(self.ctrl_frame, text="Synthetic fault",
                                           fg_color="#8B2635", hover_color="#B33244",
                                           font=("Consolas", 12, "bold"),
                                           command=lambda: self._start_demo_sim(mode=3, cache_en=0, seed=0x03))
        self.btn_sim_fault.pack(side="right", padx=8, pady=6)

        # 4. BOTTOM PANEL: CYCLE-BY-CYCLE ARCHITECTURAL TRACE CONSOLE
        self.term_frame = ctk.CTkFrame(self, fg_color="#000000", corner_radius=8, border_width=1, border_color="#333333")
        self.term_frame.grid(row=2, column=0, columnspan=2, padx=10, pady=(4, 10), sticky="nsew")
        self.term_frame.grid_rowconfigure(0, weight=1)
        self.term_frame.grid_columnconfigure(0, weight=1)

        self.terminal = ctk.CTkTextbox(self.term_frame, fg_color="#000000", text_color="#00FF00",
                                       font=("Consolas", 12), wrap="none", activate_scrollbars=True)
        self.terminal.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)

        # Configure color-coded syntax tags inside underlying tk.Text widget
        tb = self.terminal._textbox
        tb.tag_config("inst",   foreground="#E0E0E0")
        tb.tag_config("stall",  foreground="#FFAA00")
        tb.tag_config("refill", foreground="#00FFFF")
        tb.tag_config("verify", foreground="#39FF14")
        tb.tag_config("fault",  foreground="#FF4444")

    # -------------------------------------------------------------------------
    # CONTROLS & TERMINAL APPEND ENGINE
    # -------------------------------------------------------------------------
    def _close(self):
        self.running = False
        if self.serial_conn is not None:
            self.serial_conn.close()
        self.destroy()

    def _select_port(self,port):
        self.port_name = port
        self.source = "LIVE"
        if self.serial_conn is not None:
            self.serial_conn.close()
            self.serial_conn = None
        self._clear_dashboard()

    def _toggle_autoscroll(self):
        self.pause_autoscroll = not self.pause_autoscroll
        if self.pause_autoscroll:
            self.btn_pause.configure(text="Pause Auto-Scroll: ON (FROZEN)", fg_color="#CC6600")
        else:
            self.btn_pause.configure(text="Pause Auto-Scroll: OFF", fg_color="#005577")
            self.terminal.see("end")

    def _clear_dashboard(self):
        self.received.clear()
        self.failures = 0
        self.last_iter = -1
        self.prev_cycles = self.prev_instret = self.prev_dmiss = 0
        self.x_iters.clear()
        self.y_raw.clear()
        self.y_filt.clear()
        self.golden_model.reset()
        self.line_raw.set_data([], [])
        self.line_filt.set_data([], [])
        self.canvas.draw_idle()
        self.terminal.delete("1.0", "end")
        self.log_line_count = 0
        self.lbl_status.configure(text=" STATUS: READY FOR NEXT RUN ", fg_color="#333333", text_color="#00FFFF")

    def _append_terminal(self, text: str, tag: str = "inst"):
        tb = self.terminal._textbox
        tb.insert("end", text + "\n", tag)
        self.log_line_count += 1
        if self.log_line_count > MAX_LOG_LINES:
            tb.delete("1.0", "200.0")
            self.log_line_count -= 199
        if not self.pause_autoscroll:
            tb.see("end")

    # -------------------------------------------------------------------------
    # SERIAL LISTENER & PARSER ENGINE
    # -------------------------------------------------------------------------
    def _start_serial_thread(self):
        def listener():
            pending = bytearray()
            while self.running:
                if self.source != "LIVE":
                    time.sleep(0.1)
                    continue
                try:
                    if self.serial_conn is None or not self.serial_conn.is_open:
                        self.serial_conn = serial.Serial(self.port_name, BAUD_RATE, timeout=0.2)
                        self.data_queue.put(("STATUS", f"CONNECTED TO {self.port_name} @ {BAUD_RATE} BAUD"))
                    chunk = self.serial_conn.read(max(1,min(4096,self.serial_conn.in_waiting)))
                    pending.extend(chunk)
                    while b"\n" in pending:
                        raw_line,_,pending = pending.partition(b"\n")
                        self.data_queue.put(("LINE",raw_line.decode("ascii",errors="replace").strip()))
                    if len(pending)>16384:
                        pending.clear()
                        self.data_queue.put(("LINE","[ERROR] Oversized serial line discarded"))
                except Exception:
                    if self.serial_conn is not None:
                        self.serial_conn.close()
                    self.serial_conn = None
                    pending.clear()
                    time.sleep(1.0)

        threading.Thread(target=listener, daemon=True).start()

    def _process_queue(self):
        try:
            for _ in range(40): # Process up to 40 messages per GUI frame
                msg_type, payload = self.data_queue.get_nowait()
                if msg_type == "STATUS":
                    self.lbl_status.configure(text=f" {payload} ", text_color="#00FFFF")
                elif msg_type == "LINE":
                    self._handle_uart_line(payload)
        except queue.Empty:
            pass
        self.after(25, self._process_queue)

    def _handle_uart_line(self, line: str):
        # 1. Check for Bounded Run Completion Sentinel
        if line == "DEMO_COMPLETE":
            self.lbl_status.configure(text=f" {self.source}: {len(self.received)}/100 received; {self.failures} failures ",
                                      fg_color="#1B5E20" if len(self.received)==100 and self.failures==0 else "#8B2635", text_color="#FFFFFF")
            self._append_terminal("================================================================================", "verify")
            self._append_terminal("[END] Sentinel received; physical LEDs and halt state are not present in this protocol.", "verify")
            return

        # 2. Check for Telemetry CSV Line
        if line.startswith("CSV,"):
            parts = line.split(",")
            if len(parts) != 12 or any(not re.fullmatch(r"[0-9a-fA-F]{8}",v) for v in parts[1:]):
                self.failures += 1
                self._append_terminal("[PARSE ERROR] Expected CSV plus exactly 11 eight-digit hex fields", "fault")
                return
            try:
                iter_idx   = int(parts[1], 16)
                sw_val     = int(parts[2], 16)
                raw_hex    = parts[3].upper()
                filt_hex   = parts[4].upper()
                zbb_val    = int(parts[5], 16)
                div_hex    = parts[6].upper()
                cycles     = int(parts[7], 16)
                instret    = int(parts[8], 16)
                dmiss      = int(parts[9], 16)
                stalls     = int(parts[10], 16)
                wb_hex     = parts[11].upper()

                if not 0 <= iter_idx < 100 or iter_idx != self.last_iter + 1:
                    raise ValueError("Out-of-order, duplicate, or missing packet")
                self.last_iter = iter_idx
                self.received.add(iter_idx)
                if iter_idx == 0:
                    self.x_iters.clear()
                    self.y_raw.clear()
                    self.y_filt.clear()
                    self.golden_model.reset()
                    self.lbl_status.configure(text=" STATUS: EXECUTING TELEMETRY RUN... ",
                                              fg_color="#004D40", text_color="#00FFFF")

                # Host Golden Model Verification
                exp_hex, exp_cpop, desc = self.golden_model.step(iter_idx, sw_val, raw_hex)
                raw_f  = HostGoldenModel.hex_to_float(raw_hex)
                filt_f = HostGoldenModel.hex_to_float(filt_hex)
                exp_f  = HostGoldenModel.hex_to_float(exp_hex)

                # Plot finite values on Matplotlib graph
                plot_raw  = float("nan") if (math.isnan(raw_f) or math.isinf(raw_f)) else raw_f
                plot_filt = float("nan") if (math.isnan(filt_f) or math.isinf(filt_f)) else filt_f

                self.x_iters.append(iter_idx)
                self.y_raw.append(plot_raw)
                self.y_filt.append(plot_filt)

                self.line_raw.set_data(self.x_iters, self.y_raw)
                self.line_filt.set_data(self.x_iters, self.y_filt)
                self.ax.relim()
                self.ax.autoscale_view()
                self.canvas.draw_idle()

                # Update Hardware CSR Gauges
                d_cyc = (cycles-self.prev_cycles)&0xFFFFFFFF
                d_inst = (instret-self.prev_instret)&0xFFFFFFFF
                self.prev_cycles,self.prev_instret,self.prev_dmiss=cycles,instret,dmiss
                ipc_val=d_inst/d_cyc if d_cyc else 0.0
                # The fixed CSV carries no access denominators or I-cache misses.
                d_hit=i_hit=None

                self.gauge_ipc.set_value(ipc_val)
                self.gauge_dcache.set_value(d_hit)
                self.gauge_icache.set_value(i_hit)
                self.gauge_stalls.set_value(stalls)

                # Compare FPGA vs Host Golden Model
                is_match = (filt_hex == exp_hex) and (zbb_val == exp_cpop)
                status_str = "EXACT BIT MATCH (PASS)" if is_match else "FAIL: BIT MISMATCH"
                if (sw_val>>14)==3:
                    expected_div={1:0xFFFFFFFF,2:0xFFFFFFFF,3:0xFFFFFFFF,4:0x80000000,5:0xFFFFFFFF,6:0,7:1,8:0xFFFFFFFF,9:0x80000000,10:0xFFFFFFFF,11:32}.get(sw_val&255,0xFFFFFFFF)
                    is_match=is_match and int(div_hex,16)==expected_div
                if not is_match: self.failures += 1
                status_str = "EXACT BIT MATCH (PASS)" if is_match else "FAIL: BIT MISMATCH"

                self.lbl_mode.configure(
                    text=f"MODE: {desc} | SW[15:0]: 0x{sw_val:04X} | PC/LEDs: unavailable in fixed CSV"
                )
                self.lbl_fpga_vs_host.configure(
                    text=f"FPGA Computed : 0x{filt_hex} ({filt_f:10.5f})  |  Host Expected : 0x{exp_hex} ({exp_f:10.5f})\n"
                         f"Zbb CPOP Bits : {zbb_val:<2} (Host: {exp_cpop:<2})             |  RV32M Div Out : 0x{div_hex}\n"
                         f"Latest WB Reg : 0x{wb_hex}                    |  VERIFICATION  : {status_str}"
                )

                # Print concise verification record to terminal every 10th packet or in fault mode
                if (iter_idx % 10 == 0) or ((sw_val >> 14) == 0x3):
                    self._append_terminal(
                        f"[VERIFY #{iter_idx:02d}] Raw: 0x{raw_hex} | FPGA FPU: 0x{filt_hex} | Host Expected: 0x{exp_hex} | "
                        f"WB <= 0x{wb_hex} | DivOut: 0x{div_hex} | MATCH: {is_match}",
                        "verify"
                    )
            except Exception as exc:
                self.failures += 1
                self._append_terminal(f"[PARSE ERROR] {exc} -> {line}", "fault")
            return

        # 3. Handle Cycle-by-Cycle Trace Lines ([CC= ...])
        if "---------stall---------" in line or "---------flush---------" in line:
            tag = "refill" if "D-CACHE MISS REFILL" in line else "stall"
            self._append_terminal(line, tag)
        else:
            self._append_terminal(line, "inst")

    # -------------------------------------------------------------------------
    # BUILT-IN HARDWARE-ACCURATE SIMULATOR (FOR TESTING WITHOUT BOARD)
    # -------------------------------------------------------------------------
    def _start_demo_sim(self, mode: int, cache_en: int, seed: int):
        if self.sim_running:
            return
        self.sim_running = True
        self.source = "SYNTHETIC — NOT HARDWARE VERIFICATION"
        self._clear_dashboard()

        def run_sim():
            sw_val = ((mode & 0x3) << 14) | ((cache_en & 0x1) << 13) | (seed & 0xFF)
            cc = 0
            ema_f = 0.0
            alpha = HostGoldenModel.f32(seed / 255.0)
            one_m = HostGoldenModel.f32(1.0 - alpha)
            cycles_total  = 10
            instret_total = 8
            dmiss_total   = 0
            stalls_total  = 2

            for i in range(100):
                if not self.running: break
                base_val = 1.0 + (i % 16) * 0.25 + (1.8 if (i % 7 == 0) else 0.0)
                raw_f = HostGoldenModel.f32(base_val)
                raw_hex = HostGoldenModel.float_to_hex(raw_f)

                if mode == 3:
                    raw_hex  = "7FC00000" if seed == 0x03 else "7F800000"
                    filt_hex = raw_hex
                    div_hex  = "FFFFFFFF"
                else:
                    ema_f = raw_f if i == 0 else HostGoldenModel.f32(HostGoldenModel.f32(alpha * raw_f) + HostGoldenModel.f32(one_m * ema_f))
                    filt_hex = HostGoldenModel.float_to_hex(ema_f)
                    div_hex  = "00000001"

                cpop_val = HostGoldenModel.zbb_cpop(int(raw_hex, 16))

                instret_total += 12
                if (i % 4 == 0) or (cache_en == 0):
                    dmiss_total  += 1
                    stalls_total += 11
                    cycles_total += 23
                else:
                    stalls_total += 1
                    cycles_total += 13

                csv_msg = (
                    f"CSV,{i:08X},{sw_val:08X},{raw_hex},{filt_hex},{cpop_val:08X},"
                    f"{div_hex},{cycles_total:08X},{instret_total:08X},{dmiss_total:08X},"
                    f"{stalls_total:08X},{filt_hex}"
                )
                self.data_queue.put(("LINE", csv_msg))
                time.sleep(0.035)


            self.data_queue.put(("LINE", "DEMO_COMPLETE"))
            self.sim_running = False

        threading.Thread(target=run_sim, daemon=True).start()


if __name__ == "__main__":
    app = RISCVTelemetryDashboard()
    app.mainloop()
