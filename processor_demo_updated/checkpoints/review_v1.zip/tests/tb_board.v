`timescale 1ns/1ps
module tb_board;
 reg clk=0,rst=0;always #5 clk=~clk;
 wire tx;wire [15:0] led;
 nexys_a7_top #(.UART_DIV_CLOCK(1152000)) dut(.CLK100MHZ(clk),.CPU_RESETN(rst),.SW(16'h2032),.LED(led),.UART_TXD_IN(tx));
 reg [7:0] byte_value;integer i,n=0;
 reg [7:0] expected[0:3];
 initial begin expected[0]="C";expected[1]="S";expected[2]="V";expected[3]=",";#110 rst=1;end
 initial begin
 wait(rst);
 while(n<4) begin
  @(negedge tx);#300;
  for(i=0;i<8;i=i+1)begin byte_value[i]=tx;#200;end
  if(tx!==1 || byte_value!==expected[n])$fatal(1,"UART board prefix byte %d got=%h expected=%h",n,byte_value,expected[n]);
  n=n+1;
 end
 $display("BOARD PASS: firmware MMIO -> mailbox -> UART serial prefix CSV,");$finish;
 end
 initial begin #20000000;$fatal(1,"Board UART timeout");end
endmodule
