import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from dashboard import RISCVTelemetryDashboard,HostGoldenModel
class Widget:
 def __init__(self):self.value=None
 def configure(self,**kw): self.value=kw
 def set_data(self,*args):pass
 def set_value(self,x): self.value=x
 def relim(self):pass
 def autoscale_view(self):pass
 def draw_idle(self):pass
class DashboardTest(unittest.TestCase):
 def model(self):
  a=object.__new__(RISCVTelemetryDashboard)
  for n in ['lbl_status','lbl_mode','lbl_fpga_vs_host','line_raw','line_filt','ax','canvas','gauge_ipc','gauge_icache','gauge_dcache','gauge_stalls']:setattr(a,n,Widget())
  a.received=set();a.failures=0;a.last_iter=-1;a.source='RTL';a.golden_model=HostGoldenModel()
  a.x_iters=[];a.y_raw=[];a.y_filt=[];a.prev_cycles=a.prev_instret=a.prev_dmiss=0;a.logs=[]
  a._append_terminal=lambda *x:a.logs.append(x)
  return a
 def packet(self,i=0,result='3F800000'):
  return f'CSV,{i:08X},00002032,3F800000,{result},00000007,0000000E,00000100,00000080,00000001,00000005,12345678'
 def test_exact(self):
  a=self.model();a._handle_uart_line(self.packet());self.assertEqual(a.failures,0);self.assertIsNone(a.gauge_icache.value)
 def test_mismatch(self):
  a=self.model();a._handle_uart_line(self.packet(result='40000000'));self.assertEqual(a.failures,1)
 def test_duplicate(self):
  a=self.model();a._handle_uart_line(self.packet());a._handle_uart_line(self.packet());self.assertEqual(a.failures,1)
 def test_malformed(self):
  a=self.model();a._handle_uart_line('CSV,garbage');self.assertEqual(a.failures,1)
 def test_incomplete(self):
  a=self.model();a._handle_uart_line('DEMO_COMPLETE');self.assertIn('0/100',a.lbl_status.value['text'])
 def test_diagnostic_independent(self):
  expected,_,_=HostGoldenModel().step(0,0xe003,'12345678');self.assertEqual(expected,'7FC00000')
if __name__=='__main__':unittest.main()
