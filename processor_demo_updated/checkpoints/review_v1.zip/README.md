# Processor avionics demo — reviewed integration candidate

This package contains real RTL changes, compiled bare-metal firmware, a serial dashboard, and repeatable tests. **It is not a fully completed implementation of every master-spec requirement, and is not FPGA sign-off.** Read `reports/REQUIREMENTS_REVIEW.md` before presenting results.

## Build and run

1. Install RISC-V GCC/binutils (the build uses `riscv64-unknown-elf-` targeting RV32), Icarus Verilog, and Python 3.10+ with Tk.
2. `python -m pip install -r requirements.txt`
3. `make -C firmware` produces `avionics_demo.mem`, an ELF, a binary and disassembly. The supplied memory image is already built; 64 KiB of little-endian word-addressed unified RAM starts at zero. Stack starts at `0x00010000`.
4. `python tools/run_tests.py` runs the directed regressions and elaborates the board wrapper.
5. `python tests/run_modes.py` runs all four firmware modes plus the eleven diagnostic seeds; this is a slower regression. Install NumPy only if regenerating the supplied FPU differential vectors with `python tests/generate_fp_vectors.py`.
6. `python dashboard.py`; select the actual serial port. UART is 115200, 8N1. Reset/Clear clears host state; it does not reset the physical board. Press CPU_RESETN to restart the processor.
7. Vivado: from this directory, `vivado -mode batch -source board/build_vivado.tcl`. The top is `nexys_a7_top`, part `xc7a100tcsg324-1`. Review timing, utilization, and DRC before generating a bitstream. Vivado was unavailable during this work.

The synthetic buttons are labelled **synthetic** and do not establish hardware correctness. They are UI preview data. The dashboard accepts real RTL/board CSV lines; malformed packets, duplicate/out-of-order indices, bit mismatches, and incomplete runs are not silently marked as successful.

## Switch use

| Setting | Function |
|---|---|
| `SW=0x2032` | Flight EMA; caches enabled; alpha = 50/255 |
| `SW=0x0032` | Same flight with cache bypass |
| `SW=0x6032` | Profiler; six measured instruction windows printed once |
| `SW=0xA032` | Conflict-access stress plus flight stream |
| `SW=0xE001` … `0xE00B` | Diagnostic vectors 1 … 11; caches enabled |
| SW11 | Gate the entire processor/memory clock to 10 ticks/s; UART and display keep running |
| SW10 | Show software MMIO override data instead of IF PC |
| SW12 | **No FPGA UART cycle-trace engine is implemented.** Use RTL trace capture described below |

Keep cache/mode switches stable within a measured run; reset between comparisons. Dynamic alpha is polled each packet. Live cache transitions mid-refill have not been verified. A 10 Hz core tick rate is not a guaranteed 10 retired instructions/s.

## Real trace capture

`vvp reports/firmware.vvp +SW=2032 +LOG=reports/run.log +TRACE` records actual simulated WB, stall and branch-resolution signals to `reports/run.log.trace`. Without `+TRACE`, trace capture is limited to the first 5,000 simulated cycles. `+LOG` is the raw UART transcript path. Trace output is simulation-only; it is not fabricated by firmware. Disassembly in `firmware/avionics_demo.dis` maps instruction addresses to mnemonics. A stalled cycle may still retire an older WB instruction, so two records can share a cycle number. These traces are not yet the exact fully decoded visual format requested in the master prompt.

## Protocol

The authoritative format has **11 numeric fields**, despite the master prompt calling it “9-field”:

`CSV,iter,sw,input_bits,output_bits,zbb_output,div_output,cycle,instret,dcache_misses,stalls,last_wb`

Each numeric field is eight hexadecimal digits. `DEMO_COMPLETE` ends the stream. `PROFILE,name,cycles` gives a measured instruction-window delta with a back-to-back CSR baseline subtracted. It must not be advertised as an isolated execution-unit latency: instruction-cache misses and the load dependency instruction can contribute.

The fixed CSV lacks I-cache misses, memory-access denominators, PC and LED states. Consequently the dashboard shows cache hit gauges as N/A and does not invent a live PC or physical LED mirror. `last_wb` is a real hardware snapshot from the added read-only CSR `0xC08`, taken before serial formatting.

## Important architectural scope

Register addressing now uses a sixth bank bit internally: 0–31 = x0–x31; 32–63 = f0–f31. Only ID zero is hardwired. `wb_dest_reg` is therefore now 6 bits; bit 5 selects the FP bank. External consumers must use `[4:0]` as the register number and bit 5 as bank.

Supported additions for this demo are FCVT.S.W/WU (RNE), FMV.W.X, FMV.X.W, and FSGNJ-family moves. This is **not complete RV32F/Zicsr compliance**: writable fcsr/frm, other rounding modes across all operations, and the full RV32F instruction set are not supplied. Arithmetic tests here target explicit RNE. Exception LEDs reflect operation events; the added fflags/fcsr reads accumulate them, but CSR write/clear semantics are not implemented.
